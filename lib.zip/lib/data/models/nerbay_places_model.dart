class HomeNearbyPlacesModel {
  final String externalId;
  final String name;

  final double latitude;
  final double longitude;
  final double distance;

  final double rating;
  final int reviewsCount;

  final bool? isOpen;

  const HomeNearbyPlacesModel({
    required this.externalId,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.distance,
    required this.rating,
    required this.reviewsCount,
    this.isOpen,
  });
}
